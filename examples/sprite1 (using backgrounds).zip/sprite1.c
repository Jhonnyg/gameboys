/*                      Sprite 1
    --------------------------------------------------------
   | Example program to demonstrate basic background sprites|
   | on the Gb screen.                                      |
   |--------------------------------------------------------|
   |             stephen.blanksby@virgin.net                |
    --------------------------------------------------------     */

#include <gb.h>

/* Image data for the tiles, created in GameBoy tile designer */
unsigned char bkgdata[] =
{
  0x00,0x81,0x00,0x42,0x00,0x24,0x99,0x18,
  0x99,0x18,0x00,0x24,0x00,0x42,0x00,0x81,
  0x00,0x00,0x00,0x81,0x00,0xE7,0xE7,0x18,
  0xE7,0x18,0x00,0xE7,0x00,0x81,0x00,0x00
};

/* This array states that tile number 1 will be displayed */
unsigned char bkgtilea[] =
{
  1
};

/* This array states that tile number 2 will be displayed */
unsigned char bkgtileb[] =
{
  2
};


void main()
{
int i;
  /*
    This line states that data for the background tiles is defined in
    'bkgdata'. From tile 1 for 3 tiles in length
   */
  set_bkg_data(1,2,bkgdata);  

  /*
    This loop states that tile number 1 (from bkgdata) should be
    displayed as defined by the loop
   */
for(i=0 ; i<20 ; i++)
 {
 set_bkg_tiles(i,0,1,1,bkgtilea);    /*  x,y,w,h,tilenumber */
 }

/* and so on */
for(i=1 ; i<17 ; i++)
 {
 set_bkg_tiles(0,i,1,1,bkgtilea);
 }

for(i=1 ; i<17 ; i++)
 {
 set_bkg_tiles(19,i,1,1,bkgtilea);
 }

for(i=0 ; i<20 ; i++)
 {
 set_bkg_tiles(i,17,1,1,bkgtilea);
 }

for(i=0 ; i<20 ; i++)
 {
 set_bkg_tiles(i,15,1,1,bkgtileb);
 } 

SHOW_BKG;     /* I wonder what that does ?! */


}     /* end main */


/* There are probably lots of other (and maybe better) ways 
   of doing this, but thats for you to discover !
   
   If these examples help anyone I would love some feedback,
   comments, suggestions etc.
   If any of the above is incorrect I would also like to know.

   Have Fun !
   stephen.blanksby@virgin.net
   http://freespace.virgin.net/stephen.blanksby

   Thanks to Jeff, Pascal and many others !                */
